# Cluster 47 — Peter Kevin Perry — Investigative bundle

**This is a machine-generated investigative packet. Human review is required before any claim from this bundle is published.**

Nothing in this bundle is an allegation. Same-name does not imply same-person; recurring infrastructure is a triage signal, not an indictment.

## What's in here

| File | What |
| --- | --- |
| `manifest.json` | Bundle metadata (foreign_id, label, stats) |
| `entities.ftm.json` | FollowTheMoney ndjson — Persons, Companies, Addresses, Directorships, Ownerships. Drop into OpenAleph, ICIJ Datashare, or ftm-store. |
| `_index.csv` | File-by-file index with referenced FTM entity IDs |
| `documents/research_brief.md` | One-page narrative summary (the place to start) |
| `documents/timeline.md` | Dated events extracted from records + web hits |
| `documents/corroborate_graph_paths.md` | Plain-language graph narratives |
| `documents/evidence_ledger.csv` | Every claim, sourced and confidence-tagged |
| `documents/discovery_delta.csv` | What was publicly known vs. what GoldenMatch added |
| `documents/underreported_entities.csv` | High-graph-degree entities with no web presence |
| `documents/hit_scores.csv` | External-search results, scored by domain quality |
| `documents/search_results.json` | Raw Tavily output (provenance for hit_scores) |
| `documents/*.csv` | First-stage validation outputs (overlap, roles, infra, themes) |

## How to ingest

**OpenAleph (via alephclient):**

```bash
# Unzip into a working directory, then crawldir at it.
unzip cluster_47_aleph_bundle.zip -d cluster_47_bundle
alephclient -h https://your-aleph.example/ crawldir \
    --foreign-id gm-cluster-47-bundle \
    cluster_47_bundle/
```

**ICIJ Datashare:** drop the unzipped folder under your Datashare data directory. The FTM file is auto-recognized.

**ftm-store (CLI):**

```bash
ftm store iter -i entities.ftm.json -o entities.ftm.json
```

**Raw inspection:**

```bash
# Just look at the brief.
less documents/research_brief.md
```

## Stats

- Cluster size: **67** entities
- Priority score: **0.562259**
- Officer reuse rate: **0.985**
- Address reuse rate: **0.985**
- FTM entities in bundle: **449**
- Files in bundle: **21**

## Cautious framing

- Same-name records have not been verified as the same individual.
- Recurring infrastructure (shared registered address + officer reuse) is a common-and-legitimate feature of Malta corporate-services hubs. It is a triage signal, not an indictment.
- Web search uses Tavily, a third-party aggregator. Absence of hits is not absence of public record.
- Theme labels are keyword heuristics. The `evidence_ledger.csv` flags which claims are publication-safe and which need review.
